//
//  arctopSDK.h
//  arctopSDK
//
//  Created by Shai Kalev on 13/04/2023.
//

#import <Foundation/Foundation.h>

//! Project version number for arctopSDK.
FOUNDATION_EXPORT double ArctopSDKVersionNumber;

//! Project version string for arctopSDK.
FOUNDATION_EXPORT const unsigned char ArctopSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <arctopSDK/PublicHeader.h>


